setwd("~/Desktop/StatModeling2/Project-HDP/data/")

source("ir2.R")
library(XML)
library(tm)

#use read.directory function and make.bow function from ir.R
storiesart <- read.directory("nyt_corpus/art")
storiesmusic <- read.directory("nyt_corpus/music")

storylist <- append(storiesart,storiesmusic)

# Turn the document vector into the BoW vecotor (with each word as the name of vector and the counting 
# as its value)
# Input: a document vector from the list of documents with all the words in that document.
# Output: a corresponding BoW vector
vectorwithnames <- function(x){
  v <- as.vector(table(x))
  names(v) <- names(table(x))
  return(v)
}
listofvectors <- lapply(storylist,vectorwithnames)
mydtm <- make.BoW.frame(listofvectors)


